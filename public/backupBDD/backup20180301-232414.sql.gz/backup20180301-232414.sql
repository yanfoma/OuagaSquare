--
-- backup20180301-232414.sql.gz


DROP TABLE IF EXISTS `categorie`;
CREATE TABLE `categorie` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `resume_titre` varchar(100) NOT NULL,
  `full_titre` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_titre` (`full_titre`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `categorie` VALUES ('1','TIC1','TIC def','2018-03-01 14:33:50','2018-03-01 14:33:50');
INSERT INTO `categorie` VALUES ('3','GC','Gestion de la Comptabilit�','2017-09-26 18:43:01','2017-09-26 16:43:01');


DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE `commentaire` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `contenu` varchar(2500) NOT NULL,
  `projet_id` int(50) NOT NULL,
  `nom` varchar(250) NOT NULL,
  `avatar` varchar(1000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `commentaire` VALUES ('1','ppm L�objectif de ce projet �tant de nous doter de bases solides en complexit� algorithmique. Les objectifs sp�ci?ques sont de les permettre de comparer les algorithmes et/ou programmes et de mener des �tudes/recherches en relation avec l�optimisation ou la recherche d�heuristique.','4','Florent','1.jpg','2018-02-28 18:23:07','2017-07-26 23:41:11');
INSERT INTO `commentaire` VALUES ('2','hhhh L�objectif de ce projet �tant de nous doter de bases solides en complexit� algorithmique. Les objectifs sp�ci?ques sont de les permettre de comparer les algorithmes et/ou programmes et de mener des �tudes/recherches en relation avec l�optimisation ou la recherche d�heuristique.','4','Balkoulga','2.jpg','2018-02-28 18:23:12','2017-07-26 23:42:56');
INSERT INTO `commentaire` VALUES ('3','L�objectif de ce projet �tant de nous doter de bases solides en complexit� algorithmique. Les objectifs sp�ci?ques sont de les permettre de comparer les algorithmes et/ou programmes et de mener des �tudes/recherches en relation avec l�optimisation ou la recherche d�heuristique.','4','Florent','3.jpg','2018-02-28 18:23:16','2017-07-26 23:46:22');
INSERT INTO `commentaire` VALUES ('27','DBSsefyu','12','Balkoulga','4.jpg','2018-02-28 18:23:21','2017-10-09 11:49:19');


DROP TABLE IF EXISTS `executeur`;
CREATE TABLE `executeur` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL,
  `adresse` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `executeur` VALUES ('1','Kabore Ali','70012536','2017-07-21 21:27:21','2017-07-21 21:27:21');


DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `contenu` varchar(2000) NOT NULL,
  `destinataire` bigint(20) NOT NULL,
  `statut` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `phase`;
CREATE TABLE `phase` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `libelle` (`libelle`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `phase` VALUES ('1','D�but','2017-07-21 20:56:02','2017-07-21 20:56:02');
INSERT INTO `phase` VALUES ('2','Ex�cution','2017-07-21 20:56:19','2017-07-21 20:56:19');
INSERT INTO `phase` VALUES ('3','Fin','2017-09-26 18:44:33','2017-09-26 16:44:33');


DROP TABLE IF EXISTS `projet`;
CREATE TABLE `projet` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `resume_titre` varchar(100) DEFAULT NULL,
  `full_titre` varchar(500) DEFAULT NULL,
  `contenu` longtext,
  `cout` int(50) DEFAULT NULL,
  `responsable_id` int(50) DEFAULT NULL,
  `executeur_id` int(50) DEFAULT NULL,
  `date_debut` varchar(100) DEFAULT NULL,
  `date_fin` varchar(100) DEFAULT NULL,
  `phase_id` int(50) DEFAULT NULL,
  `categorie_id` int(50) DEFAULT NULL,
  `avatar` varchar(2550) DEFAULT NULL,
  `vue` int(100) DEFAULT NULL,
  `fichier_joint` varchar(250) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_titre` (`full_titre`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `projet` VALUES ('1','PN','Programme national','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.\n','2000000','1','1','2018-02-21','2018-02-23','1','1','1.jpg','102','1.pdf','2018-02-28 23:15:39','2017-07-21 23:14:54');
INSERT INTO `projet` VALUES ('2','PN2','Programme national3','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.\n','20000','1','1','2018-02-25','2018-02-27','2','1','2.jpg','87','2.pdf','2018-02-28 23:15:54','2017-07-21 23:16:26');
INSERT INTO `projet` VALUES ('4','Projet SEP','Suivi-Evaluation des Projets du MAAH','Le minist�re de l�Agriculture et des Am�nagements Hydrauliques (MAAH) envisage de pallier aux difficult�s li�es � la remont�e et � la consolidation des donn�es de suivi dans le processus de gestion des projets et programmes. En effet, de nombreux manquements sont relev�s au niveau du suivi des projets et programmes du fait de l�inexistence d�un syst�me fiable de gestion des diff�rents processus. \nLe projet d�informatisation du processus de gestion des projets objet de la pr�sente manifestation � int�r�t  vise � combler le d�ficit constat� au niveau des outils en r�pondant aux exigences sp�cifiques du minist�re marqu�es par :\n?	la forte d�concentration de ses services n�cessitant ainsi un syst�me plus extensible et adapt� � l�environnement ; \n?	le nombre �lev� des projets (une centaine en cours d�ex�cution) ;\n?	la n�cessaire automatisation des traitements garantissant l�int�grit� des donn�es et la fiabilisation des diff�rents reportings ; ','500000','1','1','2018-02-21','2018-02-27','2','1','3.jpg','65','3.pdf','2018-02-28 23:15:48','2017-07-24 19:41:21');
INSERT INTO `projet` VALUES ('5','Projet GCM','Gestion de la Comptabilit� Mati�res','Le Minist�re de l�Economie et des Finances (MEF) a entrepris en 2000 de mener une r�flexion afin de d�finir un cadre global et coh�rent de r�formes du syst�me de gestion budg�taire. Dans cette dynamique, un Plan d�actions pour le Renforcement de la Gestion Budg�taire (PRGB) a vu le jour en 2002 avec pour objectif global d�� Am�liorer durablement la transparence, la fiabilit� et l�efficacit� dans la gestion budg�taire �. \nL�am�lioration de la transparence dans la gestion budg�taire pr�n�e par le plan d�actions a fait ressortir la n�cessit� de la mise en place d�un outil de gestion de la comptabilit� des mati�res. ','2368420','2','1','2018-02-20','2018-02-28','3','3','4.jpg','92','4.pdf','2018-03-01 23:03:12','2018-03-01 23:03:12');


DROP TABLE IF EXISTS `responsable`;
CREATE TABLE `responsable` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `libelle_2` (`libelle`),
  KEY `libelle` (`libelle`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `responsable` VALUES ('1','Ou�draogo Fabrice','2017-09-26 19:03:25','2017-09-26 17:03:25');
INSERT INTO `responsable` VALUES ('2','Minist�re des TIC','2017-07-21 21:16:45','2017-07-21 21:16:45');


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password` (`password`),
  UNIQUE KEY `password_2` (`password`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES ('6','Balkoulga','bfo226@gmail.com','$2y$10$IRKGIrDSJI2fke4oPDbVY.tnPo65Y3IYL3LtH3gWXDrErZCz6bXjK','2017-10-09 09:09:06','2017-10-09 09:09:06');
INSERT INTO `users` VALUES ('4','Florent','Email2','$2y$10$FbgONbg8WcfwDlRoYDmx8uJT2rVUV/oZvTfmAS4HNeTQWN7T3o83y\n','2017-10-09 10:44:14','2017-09-26 12:37:22');
